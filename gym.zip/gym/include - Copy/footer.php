<footer class="">
		<div class="container">
			
			<div class="footer-bottom">
				<div class="row">
					
						<div class="copyright">@Garodi GYM
						</div>
				</div>
			</div>
		</div>
	</footer>