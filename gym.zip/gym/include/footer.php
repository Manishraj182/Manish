<footer class="">
		<div class="container">
			
			<div class="footer-bottom">
				<div class="row">
					
						<div class="copyright">@Garodi GYM2024
						</div>
				</div>
			</div>
		</div>
	</footer>